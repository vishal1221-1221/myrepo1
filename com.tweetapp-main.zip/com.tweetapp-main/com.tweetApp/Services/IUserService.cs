﻿using com.tweetapp.Models;
using com.tweetapp.Models.Dtos.UserDto;


namespace com.tweetapp.Services
{
    public interface IUserService
    {
        public Task<bool> RegisterUser(CreateUserDto userDetails);

        public Task<IEnumerable<ViewUserDto>> GetAllUsers();

        public Task<ViewUserDto> GetUserByUsername(string username);

        public Task<ViewUserDto> UserLogin(UserCredentials credential);

        public Task<bool?> IsEmailIdAlreadyExist(string emailId);

        public Task<bool> ResetPassword(string userId, string newPassword);

        public Task<bool> ValidateSecurityCredential(ForgotPasswordDto credentilas);
    }
}
