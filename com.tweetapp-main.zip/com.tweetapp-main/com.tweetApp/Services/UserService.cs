﻿using System.Text;
using com.tweetapp.Data.IRepository;
using AutoMapper;
using com.tweetapp.Models;
using Microsoft.IdentityModel.Tokens;
using com.tweetapp.Models.Dtos.UserDto;
using System.IdentityModel.Tokens.Jwt;

namespace com.tweetapp.Services
{
    public class UserService : IUserService
    {
        private readonly IUserRepository _user;
        private readonly IMapper _mapper;
        private readonly IConfiguration _config;
        static readonly log4net.ILog _log4net = log4net.LogManager.GetLogger(typeof(UserService));
        public UserService(IUserRepository repoUser, IMapper mapper, IConfiguration config)
        {
            _user = repoUser;
            _mapper = mapper;
            _config = config;
        }
        public async Task<ViewUserDto> UserLogin(UserCredentials credential)
        {
            var user = await _user.LoginUser(credential);
            if (user != null)
            {
                _log4net.Info("User Info is retreived");
                var tokenString = GenerateJSONWebToken(user);
                user.Token = tokenString;
                return _mapper.Map<ViewUserDto>(user);
            }
            _log4net.Info("User Info is null");
            return null;
        }
        public async Task<bool> RegisterUser(CreateUserDto userDetails)
        {
            try
            {
                var user = _mapper.Map<Users>(userDetails);
                bool respone = await _user.CreateUserAsync(user);
                return respone;
            }
            catch(Exception ex)
            {
                _log4net.Info(ex.Message);
                return false;
            }
        }

        public async Task<ViewUserDto> GetUserByUsername(string username)
        {
            try
            {
                var user = await _user.GetUserAsync(username);
                return _mapper.Map<ViewUserDto>(user);
            }
            catch (Exception ex)
            {
                _log4net.Info(ex.Message);
                return null;
            }

        }

        public async Task<IEnumerable<ViewUserDto>> GetAllUsers()
        {
            try
            {
                var users = await _user.GetAllUsersAsync();
                var userDetail = new List<ViewUserDto>();
                foreach (var user in users)
                {
                    userDetail.Add(_mapper.Map<ViewUserDto>(user));
                }
                return userDetail;
            }
            catch(Exception ex)
            {
                _log4net.Info(ex.Message);
                return null;
            }
            
        }

        public async Task<bool?> IsEmailIdAlreadyExist(string emailId)
        {
            try
            {
                return await _user.IsUserAlreadyExist(emailId);
            }
            catch(Exception ex)
            {
                _log4net.Info(ex.Message);
                return null;
            }
            
        }

        public string GenerateJSONWebToken(Users userInfo)
        {
            _log4net.Info("Token Is Generated!");

            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["Jwt:Key"]));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
              issuer: _config["Jwt:Issuer"],
              audience: _config["Jwt:Issuer"],
              null,
              expires: DateTime.Now.AddMinutes(30),
              signingCredentials: credentials);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        public async Task<bool> ValidateSecurityCredential(ForgotPasswordDto credentilas)
        {
            var result = await _user.CheckSecurityCredential(credentilas);
            return result;
        }

        public async Task<bool> ResetPassword(string userId, string newPassword)
        {
            var result = await _user.updatePassword(userId, newPassword);

            return result;
        }        
    }
}
