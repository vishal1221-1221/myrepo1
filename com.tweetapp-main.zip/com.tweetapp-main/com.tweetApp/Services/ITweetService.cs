﻿using com.tweetapp.Models;
using com.tweetapp.Models.Dtos.TweetDto;


namespace com.tweetapp.Services
{
    public interface ITweetService
    {
        public Task<IEnumerable<Tweets>> GetAllTweets();

        public Task<IEnumerable<Tweets>> GetUsersTweet(string userId);

        public Task<bool> Reply(string tweetId, string tweetText, string userId);

        public Task<bool> DeleteTweet(string id);

        public Task<Tweets> PostTweet(string username, CreateTweetDto tweet);

        public Task<Tweets> UpdateTweet(string id, string text, string username);

        public Task<int> UnlikeLikeTweet(string id, string username);

    }
}
