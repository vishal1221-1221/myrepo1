﻿using AutoMapper;
using com.tweetapp.Data.IRepository;
using com.tweetapp.Models;
using com.tweetapp.Models.Dtos.TweetDto;


namespace com.tweetapp.Services
{
    public class TweetService : ITweetService
    {
        private readonly ITweetRepository _tweet;
        private readonly IMapper _mapper;
        private readonly IUserRepository _user;
        static readonly log4net.ILog _log4net = log4net.LogManager.GetLogger(typeof(TweetService));
        public TweetService(ITweetRepository tweet, IMapper mapper, IUserRepository user)
        {
            _tweet = tweet;
            _mapper = mapper;
            _user = user;
        }

        public async Task<int> UnlikeLikeTweet(string id, string username)
        {
            try
            {
                return await _tweet.UnlikeLikeTweet(id, username);
            }
            catch (Exception ex)
            {
                _log4net.Info(ex.Message);
                return -1;
            }
        }
        public async Task<bool> DeleteTweet(string id)
        {
            try
            {
                return await _tweet.DeleteTweet(id);
            }
            catch(Exception ex)
            {
                _log4net.Info(ex.Message);
                return false;
            }
           
        }

        public async Task<IEnumerable<Tweets>> GetUsersTweet(string userId)
        {
            try
            {
                var tweets =  await _tweet.GetUsersTweet(userId);
                if (tweets != null)
                {
                    return tweets.OrderByDescending(m => m.DateAndTimeOfTweet);
                }
                return tweets;

            }
            catch(Exception ex)
            {
                _log4net.Info(ex.Message);
                return null;
            }
            
        }

        public async Task<IEnumerable<Tweets>> GetAllTweets()
        {
            try
            {
                var tweets = await _tweet.GetAllTweets();
                if (tweets != null)
                {
                    return tweets.OrderByDescending(m => m.DateAndTimeOfTweet);
                }
                return tweets;
            }
            catch (Exception ex)
            {
                _log4net.Info(ex.Message);
                return null;
            }

        }

        public async Task<bool> Reply(string tweetId, string tweetText, string userId)
        {
            try
            {
                var useDetail = await _user.GetUserAsync(userId);
                ReplyTweets reply = new ReplyTweets { ReplyText = tweetText, UserId = userId , DateAndTimeOfReply = DateTime.Now, FirstName = useDetail.FirstName, LastName = useDetail.LastName};
                return await _tweet.Reply(tweetId, reply);
            }
            catch(Exception ex)
            {
                _log4net.Info(ex.Message);
                return false;
            }
            
        }
        public async Task<Tweets> UpdateTweet(string id, string text, string username)
        {
            try
            {
                var userDetail = await _user.GetUserAsync(username);
                return await _tweet.UpdateTweet(id, text);
            }
            catch (Exception ex)
            {
                _log4net.Info(ex.Message);
                return null;
            }
        }

        public async Task<Tweets> PostTweet(string username, CreateTweetDto tweet)
        {
            try
            {
                var result = _mapper.Map<Tweets>(tweet);
                var userDetail = await _user.GetUserAsync(username);
                result.UserId = username;
                result.Likes = 0;
                result.Replies = new List<ReplyTweets>();
                result.FirstName = userDetail.FirstName;
                result.LastName = userDetail.LastName;
                result.LikedBy = new string[] { };
                result.DateAndTimeOfTweet = DateTime.Now;
                return await _tweet.PostTweet(result);
            }
            catch(Exception ex)
            {
                _log4net.Info(ex.Message);
                return null;
            }
           
         
        }
    }
}
