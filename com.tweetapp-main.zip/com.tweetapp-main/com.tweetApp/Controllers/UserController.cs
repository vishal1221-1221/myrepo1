﻿using com.tweetapp.Models;
using com.tweetapp.Models.Dtos.UserDto;
using com.tweetapp.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;


namespace com.tweetapp.Controllers
{
    [Authorize]
    [Route("api/v1.0/tweets")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserService _serviceUser;
        private IConfiguration _config;
        static readonly log4net.ILog _log4net = log4net.LogManager.GetLogger(typeof(UserController));
        public UserController(IUserService userService, IConfiguration config)
        {
            _serviceUser = userService;
            _config = config;
        }

        [AllowAnonymous]
        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] CreateUserDto user)
        {
            bool? isEmailAlreadyExist = await _serviceUser.IsEmailIdAlreadyExist(user.EmailId);
            if (isEmailAlreadyExist != null && isEmailAlreadyExist == true)
            {
                return StatusCode(400, new { error = $"{user.EmailId} is already registered." });
            }
            else if (isEmailAlreadyExist == null)
            {
                return StatusCode(500, new { error = "Internal error occurred!" });
            }
            var reply = await _serviceUser.RegisterUser(user);
            if (reply == false)
            {
                return StatusCode(500, new { error = $"Internal error occurred while registering the userid {user.EmailId}" });
            }
            return StatusCode(201, new { user.EmailId });
        }

        [AllowAnonymous]
        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] UserCredentials credentials)
        {
            var reply = await _serviceUser.UserLogin(credentials);
            _log4net.Info("Login initiated!");
            if (reply != null)
            {
                return Ok(reply);
            }
            return StatusCode(404, new { errorMessage = "Invalid Credentials!"});
        }

        [AllowAnonymous]
        [HttpPost]
        [Route("{username}/forgot")]
        public async Task<IActionResult> ForgotPassword([FromBody] ForgotPasswordDto credentials, [FromRoute] string username)
        {
            var isUserExist = await _serviceUser.IsEmailIdAlreadyExist(credentials.EmailId);
            if (isUserExist != null && isUserExist == true)
            {
                var reply = await _serviceUser.ValidateSecurityCredential(credentials);
                if (reply)
                {
                    var result = await _serviceUser.ResetPassword(username, credentials.Password);
                    if (result)
                        return Ok(new { Message = "Passord reset successfull" });
                }

            }
            return BadRequest();
        }

        [HttpGet("users/all")]
        public async Task<IActionResult> GetAllUsers()
        {
            var reply = await _serviceUser.GetAllUsers();
            return Ok(reply);
        }

        [HttpGet("user/search/{userName}", Name = "GetUser")]
        public async Task<IActionResult> GetUserByUsername(string userName)
        {
            var reply = await _serviceUser.GetUserByUsername(userName);
            if (reply != null) { return Ok(reply); }
            return StatusCode(404, new { error = $"{userName} not found!" });
        }
    }
}
