﻿using com.tweetapp.Models.Dtos.TweetDto;
using com.tweetapp.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace com.tweetapp.Controllers
{
    [Authorize]
    [Route("api/v1.0/tweets")]
    [ApiController]
    public class TweetController : ControllerBase
    {
        private readonly ITweetService _serviceTweet;
        public TweetController(ITweetService serviceUser)
        {
            _serviceTweet = serviceUser;
        }

        [HttpGet("all")]
        public async Task<IActionResult> GetAllTweets()
        {
            var reply = await _serviceTweet.GetAllTweets();
            if (reply != null) { return Ok(reply); }
            return StatusCode(500, new { errorMessage = "Internal Server Error!" });

        }
        [HttpGet("{userName}")]
        public async Task<IActionResult> GetAllTweetOfUsers(string userName)
        {
            var reply = await _serviceTweet.GetUsersTweet(userName);
            if (reply != null) { return Ok(reply); }
            return StatusCode(500, new { errorMessage = "Internal Server Error!" });
        }

        [HttpPost("{userName}/add")]
        public async Task<IActionResult> PostTweet(string userName, [FromBody] CreateTweetDto tweet)
        {
            if (!ModelState.IsValid) { return StatusCode(400, ModelState); }
            var reply = await _serviceTweet.PostTweet(userName, tweet);
            if (reply != null) { return StatusCode(201, reply); }
            return StatusCode(500, new { errorMessage = "Internal Server Error!" });
        }

        [HttpDelete("{userName}/delete/{id}")]
        public async Task<IActionResult> DeleteTweet(string id,string userName)
        {
            var reply = await _serviceTweet.DeleteTweet(id);
            if (reply) { return StatusCode(204, new { msg = "Resource deleted sucessfully" }); }
            return StatusCode(500, new { errorMessage = "Internal Server Error!" });
        }
        
        [HttpPut("{userName}/update/{id}")]
        public async Task<IActionResult> UpdateTweet(string userName, string id, [FromBody] CreateTweetDto updatedText)
        {
            if (!ModelState.IsValid) { return StatusCode(400, ModelState); }
            var reply = await _serviceTweet.UpdateTweet(id, updatedText.TweetText, userName);
            if (reply != null) { return StatusCode(201, reply); }
            return StatusCode(500, new { errorMessage = "Internal Server Error!" });
        }

        [HttpPut("{username}/like/{tweetId}")]
        public async Task<IActionResult> LlikeUnlikeTweet(string tweetId, string username)
        {
            var reply = await _serviceTweet.UnlikeLikeTweet(tweetId, username);
            if (reply >= 0)
            {
                return Ok(reply);
            }
            return StatusCode(500, new { errorMessage = "Internal Server Error!" });
        }

        [HttpPut("{userName}/reply/{id}")]
        public async Task<IActionResult> ReplyTweet(string userName, string id,[FromBody] CreateTweetDto replyText)
        {
            if (!ModelState.IsValid) { return StatusCode(400, ModelState); }
            var reply = await _serviceTweet.Reply(id, replyText.TweetText, userName);
            return StatusCode(201, reply);
        }
    }
}
