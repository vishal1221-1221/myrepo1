﻿using AutoMapper;
using com.tweetapp.Models;
using com.tweetapp.Models.Dtos.TweetDto;
using com.tweetapp.Models.Dtos.UserDto;

namespace com.tweetapp.Mapper
{
    public class UserDataMapper : Profile
    {
        public UserDataMapper()
        {
            CreateMap<CreateUserDto, Users>().ReverseMap();
            CreateMap<ViewUserDto, Users>().ReverseMap();
            CreateMap<ViewUserDto, CreateUserDto>().ReverseMap();

            CreateMap<CreateTweetDto, Tweets>();

        }
    }
}
