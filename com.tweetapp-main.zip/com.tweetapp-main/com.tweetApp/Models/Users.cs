﻿using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;


namespace com.tweetapp.Models
{
    [BsonIgnoreExtraElements]
    public class Users
    {
        [BsonId]
        [BsonRepresentation(MongoDB.Bson.BsonType.ObjectId)]
        public string Id { get; set; }

        [EmailAddress]
        [BsonElement("emailId")]
        public string EmailId { get; set; }

        [BsonElement("firstName")]
        public string FirstName { get; set; }

        [BsonElement("lastName")]
        public string LastName { get; set; }

        [BsonElement("UserName")]
        public string Username { get; set; }

        [BsonElement("password")]
        public string Password { get; set; }

        [DataType(DataType.Date)]
        [BsonElement("dateofbirth")]
        public DateTime? DateOfBirth { get; set; }

        [BsonElement("gender")]
        public string Gender { get; set; }
        
        [BsonElement("securityQuestion")]
        public int SecurityQuestion { get; set; }

        [BsonElement("securityAnswer")]
        public string SecurityAnswer { get; set; }

        public string Token { get; set; }
    }
}
