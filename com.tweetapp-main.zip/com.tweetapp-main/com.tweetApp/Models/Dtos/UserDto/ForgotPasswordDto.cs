﻿using MongoDB.Bson.Serialization.Attributes;
using System.ComponentModel.DataAnnotations;


namespace com.tweetapp.Models.Dtos.UserDto
{
    public class ForgotPasswordDto
    {
        [Required]
        public string EmailId { get; set; }

        [Required]
        public int SecurityQuestion { get; set; }

        [Required]
        public string SecurityAnswer { get; set; }
        [Required(ErrorMessage = "Password is Required!")]
        [StringLength(20, ErrorMessage = "Password length must be between 6 to 20", MinimumLength = 6)]
        [BsonElement("password")]
        public string Password { get; set; }

        [Required(ErrorMessage = "Confirm Password is Required!")]
        [Compare("Password")]
        public string ConfirmPassword { get; set; }
    }
}
