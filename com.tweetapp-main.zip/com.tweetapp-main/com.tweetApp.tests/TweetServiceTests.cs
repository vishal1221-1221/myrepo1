using NUnit.Framework;
using com.tweetapp.Models;
using com.tweetapp.Models.Dtos.TweetDto;
using com.tweetapp.Data.IRepository;
using com.tweetapp.Services;
using MongoDB.Bson;
using Moq;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace com.tweetApp.tweetServiceTests
{
    public class Tests
    {
        private Tweets tweets;
        private List<Tweets> tweetList;
        private CreateTweetDto createTweetDto;
        private int i;

        [SetUp]
        public void Setup()
        {
            tweets = new Tweets()
            {
                FirstName = "Achintya",
                LastName = "Mithal",
                TweetText = "hello this is my tweet",
                Id = ObjectId.GenerateNewId().ToString(),
                UserId = "AMithal",
                Likes = 1
            };
            createTweetDto = new CreateTweetDto()
            {
                TweetText = "helllo this my tweet"
            };
            tweetList = new List<Tweets> { tweets };
        }


        [Test]
        public void GetUsersTweetValidTest()
        {
            Mock<ITweetService> mock = new Mock<ITweetService>();
            mock.Setup(m => m.GetUsersTweet(tweets.UserId)).ReturnsAsync(tweetList);
            Task<IEnumerable<Tweets>> u = mock.Object.GetUsersTweet(tweets.UserId);
            Assert.AreEqual(u.Result, tweetList);
        }

        [Test]
        public void GetUserTweetsInValidTest()
        {
            Mock<ITweetService> mock = new Mock<ITweetService>();
            mock.Setup(m => m.GetUsersTweet(tweets.UserId)).ReturnsAsync(tweetList);
            Task<IEnumerable<Tweets>> u = mock.Object.GetUsersTweet("bmithal");
            Assert.AreNotEqual(u.Result, tweetList);
        }

        [Test]
        public void GetAllTweetsValidTest()
        {
            Mock<ITweetService> mock = new Mock<ITweetService>();
            mock.Setup(m => m.GetAllTweets()).ReturnsAsync(tweetList);
            Task<IEnumerable<Tweets>> u = mock.Object.GetAllTweets();
            Assert.AreEqual(u.Result, tweetList);
        }
        [Test]
        public void GetAllTweetsInValidTest()
        {
            Mock<ITweetService> mock = new Mock<ITweetService>();
            mock.Setup(m => m.GetAllTweets()).ReturnsAsync(new List<Tweets>());
            Task<IEnumerable<Tweets>> u = mock.Object.GetAllTweets();
            Assert.AreNotEqual(u.Result, tweetList);
        }

        [Test]
        public void DeleteTweetValidTest()
        {
            Mock<ITweetService> mock = new Mock<ITweetService>();
            mock.Setup(m => m.DeleteTweet(tweets.Id)).ReturnsAsync(true);
            Task<bool> u = mock.Object.DeleteTweet(tweets.Id);
            Assert.AreEqual(u.Result, true);
        }

        [Test]
        public void DeleteTweetInValidTest()
        {
            Mock<ITweetService> mock = new Mock<ITweetService>();
            mock.Setup(m => m.DeleteTweet(tweets.Id)).ReturnsAsync(true);
            Task<bool> u = mock.Object.DeleteTweet("223");
            Assert.AreNotEqual(u.Result, true);
        }
        [Test]
        public void UpdateTweetValidTest()
        {
            Mock<ITweetService> mock = new Mock<ITweetService>();
            mock.Setup(m => m.UpdateTweet(tweets.Id,tweets.TweetText, tweets.UserId)).ReturnsAsync(tweets);
            Task<Tweets> u = mock.Object.UpdateTweet(tweets.Id,tweets.TweetText,tweets.UserId);
            Assert.AreEqual(u.Result, tweets);
        }

        [Test]
        public void UpdateTweetinValidTest()
        {
            Mock<ITweetService> mock = new Mock<ITweetService>();
            mock.Setup(m => m.UpdateTweet(tweets.Id, tweets.TweetText,tweets.UserId)).ReturnsAsync(tweets);
            Task<Tweets> u = mock.Object.UpdateTweet("5555", tweets.TweetText,tweets.UserId);
            Assert.AreNotEqual(u.Result, tweets);
        }

        [Test]
        public void PostTweetValidTest()
        {
            Mock<ITweetService> mock = new Mock<ITweetService>();
            mock.Setup(m => m.PostTweet(tweets.UserId,createTweetDto)).ReturnsAsync(tweets);
            Task<Tweets> u = mock.Object.PostTweet(tweets.UserId, createTweetDto);
            Assert.AreEqual(u.Result, tweets);
        }
        [Test]
        public void PostTweetInValidTest()
        {
            Mock<ITweetService> mock = new Mock<ITweetService>();
            mock.Setup(m => m.PostTweet(tweets.UserId, createTweetDto)).ReturnsAsync(tweets);
            Task<Tweets> u = mock.Object.PostTweet("jhjhjkk",createTweetDto);
            Assert.AreNotEqual(u.Result, tweets);
        }

        [Test]
        public void ReplyValidTest()
        {
            Mock<ITweetService> mock = new Mock<ITweetService>();
            mock.Setup(m => m.Reply(tweets.Id, tweets.UserId,"hello this my reply")).ReturnsAsync(true);
            Task<bool> u = mock.Object.Reply(tweets.Id, tweets.UserId, "hello this my reply");
            Assert.AreEqual(u.Result, true);
        }
        [Test]
        public void ReplyInValidTest()
        {
            Mock<ITweetService> mock = new Mock<ITweetService>();
            mock.Setup(m => m.Reply(tweets.Id, tweets.UserId, "hello this my reply")).ReturnsAsync(true);
            Task<bool> u = mock.Object.Reply("jsjsj","3434", "kekdijrcfudrcfdrih");
            Assert.AreNotEqual(u.Result, true);
        }
        [Test]
        public void UnlikeLikeTweetValidTest()
        {
            Mock<ITweetService> mock = new Mock<ITweetService>();
            mock.Setup(m => m.UnlikeLikeTweet(tweets.UserId, "bmithal")).ReturnsAsync(i);
            Task<int> u = mock.Object.UnlikeLikeTweet(tweets.UserId, "bmithal");
            Assert.AreEqual(u.Result, i);
        }

        [Test]
        public void UnlikeLikeTweetinValidTest()
        {
            Mock<ITweetService> mock = new Mock<ITweetService>();
            mock.Setup(m => m.UnlikeLikeTweet(tweets.UserId, "bmithal")).ReturnsAsync(i);
            Task<int> u = mock.Object.UnlikeLikeTweet("555", "bmithal");
            Assert.AreEqual(u.Result, i);
        }

    }
}