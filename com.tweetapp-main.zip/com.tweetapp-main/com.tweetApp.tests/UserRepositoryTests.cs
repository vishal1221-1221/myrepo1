using NUnit.Framework;
using com.tweetapp.Models;
using com.tweetapp.Data.IRepository;
using com.tweetapp.Services;
using com.tweetapp.Models.Dtos.UserDto;
using MongoDB.Bson;
using Moq;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace com.tweetApp.tests
{
    public class Tests
    {
        private Users user;
        private List<Users> userList;
        private bool ze = true;
        private UserCredentials createUser;
        private UserCredentials invalidUser;
        private ForgotPasswordDto forgotPassword;
        private ForgotPasswordDto invalidforgotPassword;


        [SetUp]
        public void Setup()
        {
            user = new Users()
            {
                FirstName = "Achintya",
                LastName = "Mithal",
                EmailId = "abc@gmail.com",
                Username = "amithal",
                Password = "achintya",
                Id = ObjectId.GenerateNewId().ToString(),
                SecurityAnswer = "bhau",
                SecurityQuestion = 0

            };
            createUser = new UserCredentials()
            {
                EmailId = "abc@gmail.com",            
                Password = "achintya"
            };
            invalidUser = new UserCredentials()
            {
                EmailId = "abc@gmail.com",
                Password = "bhavya"
            };
            forgotPassword = new ForgotPasswordDto()
            {
                SecurityQuestion = 0,
                SecurityAnswer = "bhau",
                EmailId = "abc@gmail.com",
                Password = "bhavya",
                ConfirmPassword = "bhavya"
            };
            invalidforgotPassword = new ForgotPasswordDto()
            {
                SecurityQuestion = 0,
                SecurityAnswer = "kkkk",
                EmailId = "abc@gmail.com",
                Password = "bhavya",
                ConfirmPassword = "bhavya"
            };

            userList = new List<Users> { user };
        }


        [Test]
        public void Test1()
        {
            Mock<IUserRepository> mock = new Mock<IUserRepository>();
            mock.Setup(m => m.GetUserAsync(user.Username)).ReturnsAsync(user);
            Task<Users> u = mock.Object.GetUserAsync(user.Username);
            Assert.AreEqual(u.Result, user);
        }

        [Test]
        public void GetUserAsyncNull()
        {
            Mock<IUserRepository> mock = new Mock<IUserRepository>();
            mock.Setup(m => m.GetUserAsync(user.Username)).ReturnsAsync(user);
            Task<Users> u = mock.Object.GetUserAsync("bhavya");
            Assert.AreNotEqual(u.Result, user);
        }

        [Test]
        public void GetAllUsersValid()
        {
            Mock<IUserRepository> mock = new Mock<IUserRepository>();
            mock.Setup(m => m.GetAllUsersAsync()).ReturnsAsync(userList);
            Task<IEnumerable<Users>> u = mock.Object.GetAllUsersAsync();
            Assert.AreEqual(u.Result, userList);
        }

        [Test]
        public void GetAllUsersInValid()
        {
            Mock<IUserRepository> mock = new Mock<IUserRepository>();
            mock.Setup(m => m.GetAllUsersAsync()).ReturnsAsync(new List<Users>());
            Task<IEnumerable<Users>> u = mock.Object.GetAllUsersAsync();
            Assert.AreNotEqual(u.Result, userList);
        }

        [Test]
        public void IsUserAlreadyExistValid()
        {
            Mock<IUserRepository> mock = new Mock<IUserRepository>();
            mock.Setup(m => m.IsUserAlreadyExist(user.EmailId)).ReturnsAsync(ze);
            Task<bool> u = mock.Object.IsUserAlreadyExist(user.EmailId);
            Assert.AreEqual(u.Result, ze);
        }

        [Test]
        public void IsUserAlreadyExistInValid()
        {
            Mock<IUserRepository> mock = new Mock<IUserRepository>();
            mock.Setup(m => m.IsUserAlreadyExist(user.EmailId)).ReturnsAsync(ze);
            Task<bool> u = mock.Object.IsUserAlreadyExist("hhh@gmail.com");
            Assert.AreNotEqual(u.Result, ze);
        }

        [Test]
        public void CreateUserAsyncValid()
        {
            Mock<IUserRepository> mock = new Mock<IUserRepository>();
            mock.Setup(m => m.CreateUserAsync(user)).ReturnsAsync(ze);
            Task<bool> u = mock.Object.CreateUserAsync(user);
            Assert.AreEqual(u.Result, ze);
        }
        [Test]
        public void CreateUserAsyncreturnsFalse()
        {
            Mock<IUserRepository> mock = new Mock<IUserRepository>();
            mock.Setup(m => m.CreateUserAsync(user)).ReturnsAsync(ze);
            Task<bool> u = mock.Object.CreateUserAsync(new Users());
            Assert.AreEqual(u.Result, false);
        }

        [Test]
        public void LoginUserValid()
        {
            Mock<IUserRepository> mock = new Mock<IUserRepository>();
            mock.Setup(m => m.LoginUser(createUser)).ReturnsAsync(user);
            Task<Users> u = mock.Object.LoginUser(createUser);
            Assert.AreEqual(u.Result, user);
        }

        [Test]
        public void LoginUserInValid()
        {
            Mock<IUserRepository> mock = new Mock<IUserRepository>();
            mock.Setup(m => m.LoginUser(createUser)).ReturnsAsync(user);
            Task<Users> u = mock.Object.LoginUser(invalidUser);
            Assert.AreNotEqual(u.Result, user);
        }

        [Test]
        public void updatePasswordValid()
        {
            Mock<IUserRepository> mock = new Mock<IUserRepository>();
            mock.Setup(m => m.updatePassword(user.Username,"bhavya")).ReturnsAsync(true);
            Task<bool> u = mock.Object.updatePassword(user.Username,"bhavya");
            Assert.AreEqual(u.Result, true);
        }
        [Test]
        public void updatePasswordinValid()
        {
            Mock<IUserRepository> mock = new Mock<IUserRepository>();
            mock.Setup(m => m.updatePassword(user.Username, "bhavya")).ReturnsAsync(true);
            Task<bool> u = mock.Object.updatePassword("jklpo", "bhavya");
            Assert.AreNotEqual(u.Result, true);
        }
        [Test]
        public void CheckSecurityCredentialValid()
        {
            Mock<IUserRepository> mock = new Mock<IUserRepository>();
            mock.Setup(m => m.CheckSecurityCredential(forgotPassword)).ReturnsAsync(true);
            Task<bool> u = mock.Object.CheckSecurityCredential(forgotPassword);
            Assert.AreEqual(u.Result, true);
        }
        [Test]
        public void CheckSecurityCredentialInValid()
        {
            Mock<IUserRepository> mock = new Mock<IUserRepository>();
            mock.Setup(m => m.CheckSecurityCredential(forgotPassword)).ReturnsAsync(true);
            Task<bool> u = mock.Object.CheckSecurityCredential(invalidforgotPassword);
            Assert.AreNotEqual(u.Result, true);
        }

    }
}