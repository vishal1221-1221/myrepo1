using NUnit.Framework;
using com.tweetapp.Models;
using com.tweetapp.Data.IRepository;
using MongoDB.Bson;
using Moq;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace com.tweetApp.tweetRepoTests
{
    public class Tests
    {
        private Tweets tweets;
        private List<Tweets> tweetList;
        private ReplyTweets replyTweets;
        private int i;

        [SetUp]
        public void Setup()
        {
            tweets = new Tweets()
            {
                FirstName = "Achintya",
                LastName = "Mithal",
                TweetText = "hello this is my tweet",
                Id = ObjectId.GenerateNewId().ToString(),
                UserId = "AMithal",
                Likes = 1
            };
            replyTweets = new ReplyTweets()
            {
                ReplyText = "very nice post",
                UserId = ObjectId.GenerateNewId().ToString(),
                FirstName ="Bhavya",
                LastName = "Mithal"

            };
            tweetList = new List<Tweets> { tweets };
        }


        [Test]
        public void GetUserTweetsValid()
        {
            Mock<ITweetRepository> mock = new Mock<ITweetRepository>();
            mock.Setup(m => m.GetUsersTweet(tweets.UserId)).ReturnsAsync(tweetList);
            Task<IEnumerable<Tweets>> u = mock.Object.GetUsersTweet(tweets.UserId);
            Assert.AreEqual(u.Result, tweetList);
        }

        [Test]
        public void GetUserTweetsInValid()
        {
            Mock<ITweetRepository> mock = new Mock<ITweetRepository>();
            mock.Setup(m => m.GetUsersTweet(tweets.UserId)).ReturnsAsync(tweetList);
            Task<IEnumerable<Tweets>> u = mock.Object.GetUsersTweet("bmithal");
            Assert.AreNotEqual(u.Result, tweetList);
        }

        [Test]
        public void GetAllTweetsValid()
        {
            Mock<ITweetRepository> mock = new Mock<ITweetRepository>();
            mock.Setup(m => m.GetAllTweets()).ReturnsAsync(tweetList);
            Task<IEnumerable<Tweets>> u = mock.Object.GetAllTweets();
            Assert.AreEqual(u.Result, tweetList);
        }
        [Test]
        public void GetAllTweetsInValid()
        {
            Mock<ITweetRepository> mock = new Mock<ITweetRepository>();
            mock.Setup(m => m.GetAllTweets()).ReturnsAsync(new List<Tweets>());
            Task<IEnumerable<Tweets>> u = mock.Object.GetAllTweets();
            Assert.AreNotEqual(u.Result, tweetList);
        }

        [Test]
        public void DeleteTweetValid()
        {
            Mock<ITweetRepository> mock = new Mock<ITweetRepository>();
            mock.Setup(m => m.DeleteTweet(tweets.Id)).ReturnsAsync(true);
            Task<bool> u = mock.Object.DeleteTweet(tweets.Id);
            Assert.AreEqual(u.Result, true);
        }

        [Test]
        public void DeleteTweetInValid()
        {
            Mock<ITweetRepository> mock = new Mock<ITweetRepository>();
            mock.Setup(m => m.DeleteTweet(tweets.Id)).ReturnsAsync(true);
            Task<bool> u = mock.Object.DeleteTweet("223");
            Assert.AreNotEqual(u.Result, true);
        }
        [Test]
        public void UpdateTweetValid()
        {
            Mock<ITweetRepository> mock = new Mock<ITweetRepository>();
            mock.Setup(m => m.UpdateTweet(tweets.Id,tweets.TweetText)).ReturnsAsync(tweets);
            Task<Tweets> u = mock.Object.UpdateTweet(tweets.Id,tweets.TweetText);
            Assert.AreEqual(u.Result, tweets);
        }

        [Test]
        public void UpdateTweetinValid()
        {
            Mock<ITweetRepository> mock = new Mock<ITweetRepository>();
            mock.Setup(m => m.UpdateTweet(tweets.Id, tweets.TweetText)).ReturnsAsync(tweets);
            Task<Tweets> u = mock.Object.UpdateTweet("5555", tweets.TweetText);
            Assert.AreNotEqual(u.Result, tweets);
        }

        [Test]
        public void PostTweetValid()
        {
            Mock<ITweetRepository> mock = new Mock<ITweetRepository>();
            mock.Setup(m => m.PostTweet(tweets)).ReturnsAsync(tweets);
            Task<Tweets> u = mock.Object.PostTweet(tweets);
            Assert.AreEqual(u.Result, tweets);
        }
        [Test]
        public void PostTweetInValid()
        {
            Mock<ITweetRepository> mock = new Mock<ITweetRepository>();
            mock.Setup(m => m.PostTweet(tweets)).ReturnsAsync(tweets);
            Task<Tweets> u = mock.Object.PostTweet(new Tweets());
            Assert.AreNotEqual(u.Result, tweets);
        }

        [Test]
        public void ReplyValid()
        {
            Mock<ITweetRepository> mock = new Mock<ITweetRepository>();
            mock.Setup(m => m.Reply(tweets.UserId,replyTweets)).ReturnsAsync(true);
            Task<bool> u = mock.Object.Reply(tweets.UserId, replyTweets);
            Assert.AreEqual(u.Result, true);
        }
        [Test]
        public void ReplyInValid()
        {
            Mock<ITweetRepository> mock = new Mock<ITweetRepository>();
            mock.Setup(m => m.Reply(tweets.UserId, replyTweets)).ReturnsAsync(true);
            Task<bool> u = mock.Object.Reply("3434", replyTweets);
            Assert.AreNotEqual(u.Result, true);
        }
        [Test]
        public void UnlikeLikeTweetValid()
        {
            Mock<ITweetRepository> mock = new Mock<ITweetRepository>();
            mock.Setup(m => m.UnlikeLikeTweet(tweets.UserId, "bmithal")).ReturnsAsync(i);
            Task<int> u = mock.Object.UnlikeLikeTweet(tweets.UserId, "bmithal");
            Assert.AreEqual(u.Result, i);
        }

        [Test]
        public void UnlikeLikeTweetinValid()
        {
            Mock<ITweetRepository> mock = new Mock<ITweetRepository>();
            mock.Setup(m => m.UnlikeLikeTweet(tweets.UserId, "bmithal")).ReturnsAsync(i);
            Task<int> u = mock.Object.UnlikeLikeTweet("555", "bmithal");
            Assert.AreEqual(u.Result, i);
        }

    }
}