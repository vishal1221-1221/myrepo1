using NUnit.Framework;
using com.tweetapp.Models;
using com.tweetapp.Data.IRepository;
using com.tweetapp.Services;
using com.tweetapp.Models.Dtos.UserDto;
using MongoDB.Bson;
using Moq;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace com.tweetApp.userServiceTests
{
    public class Tests
    {
        private ViewUserDto viewuser;
        private CreateUserDto createuser;
        private List<ViewUserDto> userlist;
        private UserCredentials userCred;
        private UserCredentials userInvalidCred;
        private ForgotPasswordDto forgotPassword;

        [SetUp]
        public void Setup()
        {
            viewuser = new ViewUserDto()
            {
                FirstName = "Achintya",
                LastName = "Mithal",
                EmailId = "abc@gmail.com",
                Username = "amithal",
                Gender = "male"
            };
            userCred = new UserCredentials()
            {
                EmailId = "abc@gmail.com",
                Password = "achintya"
            };
            userInvalidCred = new UserCredentials()
            {
                EmailId = "abc@gmail.com",
                Password = "bhavuiop"
            };
            createuser = new CreateUserDto()
            {
                DateOfBirth = DateTime.Now,
                Username = "bmithal",
                FirstName ="Bhavya",
                LastName = "Mithal",
                EmailId = "abc@gmail.com",
                Password = "achintya",
                ConfirmPassword = "achintya",
                Gender = "male",
                SecurityQuestion = 0,
                SecurityAnswer = "bhau"

            };
            forgotPassword = new ForgotPasswordDto()
            {
                SecurityQuestion = 0,
                SecurityAnswer = "bhau",
                EmailId = "abc@gmail.com",
                Password = "bhavya",
                ConfirmPassword = "bhavya"
            };
            userlist = new List<ViewUserDto> { viewuser };
        }

        [Test]
        public void GetAllUsersServiceTestValidTest()
        {
            Mock<IUserService> mock = new Mock<IUserService>();
            mock.Setup(m => m.GetAllUsers()).ReturnsAsync(userlist);
            Task<IEnumerable<ViewUserDto>> u = mock.Object.GetAllUsers();
            Assert.AreEqual(u.Result, userlist);
        }
        [Test]
        public void GetAllUsersServiceTestInValidTest()
        {
            Mock<IUserService> mock = new Mock<IUserService>();
            mock.Setup(m => m.GetAllUsers()).ReturnsAsync(new List<ViewUserDto>());
            Task<IEnumerable<ViewUserDto>> u = mock.Object.GetAllUsers();
            Assert.AreNotEqual(u.Result, userlist);
        }
        [Test]
        public void GetUserByUsernameValidTest()
        {
            Mock<IUserService> mock = new Mock<IUserService>();
            mock.Setup(m => m.GetUserByUsername(viewuser.Username)).ReturnsAsync(viewuser);
            Task<ViewUserDto> u = mock.Object.GetUserByUsername(viewuser.Username);
            Assert.AreEqual(u.Result, viewuser);
        }
        [Test]
        public void GetUserByUsernameInValidTest()
        {
            Mock<IUserService> mock = new Mock<IUserService>();
            mock.Setup(m => m.GetUserByUsername(viewuser.Username)).ReturnsAsync(viewuser);
            Task<ViewUserDto> u = mock.Object.GetUserByUsername("bhaiop");
            Assert.AreNotEqual(u.Result, viewuser);
        }

        [Test]
        public void RegisterUserValidTest()
        {
            Mock<IUserService> mock = new Mock<IUserService>();
            mock.Setup(m => m.RegisterUser(createuser)).ReturnsAsync(true);
            Task<bool> u = mock.Object.RegisterUser(createuser);
            Assert.AreEqual(u.Result, true);
        }
        [Test]
        public void RegisterUserInValidTest()
        {
            Mock<IUserService> mock = new Mock<IUserService>();
            mock.Setup(m => m.RegisterUser(createuser)).ReturnsAsync(true); 
            Task<bool> u = mock.Object.RegisterUser(new CreateUserDto());
            Assert.AreNotEqual(u.Result, true);
        }
        [Test]
        public void UserLoginValidTest()
        {
            Mock<IUserService> mock = new Mock<IUserService>();
            mock.Setup(m => m.UserLogin(userCred)).ReturnsAsync(viewuser);
            Task<ViewUserDto> u = mock.Object.UserLogin(userCred);
            Assert.AreEqual(u.Result, viewuser);
        }
        [Test]
        public void UserLoginInValidTest()
        {
            Mock<IUserService> mock = new Mock<IUserService>();
            mock.Setup(m => m.UserLogin(userCred)).ReturnsAsync(viewuser);
            Task<ViewUserDto> u = mock.Object.UserLogin(userInvalidCred);
            Assert.AreNotEqual(u.Result, viewuser);
        }

        [Test]
        public void IsEmailIdAlreadyExistValidTest()
        {
            Mock<IUserService> mock = new Mock<IUserService>();
            mock.Setup(m => m.IsEmailIdAlreadyExist(userCred.EmailId)).ReturnsAsync(true);
            Task<bool?> u = mock.Object.IsEmailIdAlreadyExist(userCred.EmailId);
            Assert.AreEqual(u.Result, true);
        }

        [Test]
        public void IsEmailIdAlreadyExistInValidTest()
        {
            Mock<IUserService> mock = new Mock<IUserService>();
            mock.Setup(m => m.IsEmailIdAlreadyExist(userCred.EmailId)).ReturnsAsync(true);
            Task<bool?> u = mock.Object.IsEmailIdAlreadyExist("jjjj@gmail.com");
            Assert.AreNotEqual(u.Result, true);
        }

        [Test]
        public void ResetPasswordValidTest()
        {
            Mock<IUserService> mock = new Mock<IUserService>();
            mock.Setup(m => m.ResetPassword(viewuser.Username,"newpassword")).ReturnsAsync(true);
            Task<bool> u = mock.Object.ResetPassword(viewuser.Username,"newpassword");
            Assert.AreEqual(u.Result, true);
        }
        [Test]
        public void ResetPasswordInValidUsernameTest()
        {
            Mock<IUserService> mock = new Mock<IUserService>();
            mock.Setup(m => m.ResetPassword(viewuser.Username, "newpassword")).ReturnsAsync(true);
            Task<bool> u = mock.Object.ResetPassword("ghlops", "newpassword");
            Assert.AreNotEqual(u.Result, true);
        }
        [Test]
        public void ValidateSecurityCredentialValidTest()
        {
            Mock<IUserService> mock = new Mock<IUserService>();
            mock.Setup(m => m.ValidateSecurityCredential(forgotPassword)).ReturnsAsync(true);
            Task<bool> u = mock.Object.ValidateSecurityCredential(forgotPassword);
            Assert.AreEqual(u.Result, true);
        }
        [Test]
        public void ValidateSecurityCredentialInValidTest()
        {
            Mock<IUserService> mock = new Mock<IUserService>();
            mock.Setup(m => m.ValidateSecurityCredential(forgotPassword)).ReturnsAsync(true);
            Task<bool> u = mock.Object.ValidateSecurityCredential(new ForgotPasswordDto());
            Assert.AreNotEqual(u.Result, true);
        }
    }
}