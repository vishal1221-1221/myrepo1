Hi welcome to tweet app!!!

1.To setup just paste your mongodb connection string in appsettings.json file under TweetAppDBSettings->Connection string.
2.Make two new collections and put their names under "UsersCollectionName" and "tweetsCollectionName".
3.Run the api, user register end point in Users controller to register new user which will create an entry for users collection.
4.Similarly after registering login to your e-mail, use the authentication token to hit create tweet end point to create an entry for tweet.
5.You can perform the other tasks after that


Thanks!!
-Achintya Mithal