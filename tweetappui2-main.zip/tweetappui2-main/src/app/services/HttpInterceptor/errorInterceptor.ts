import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor } from '@angular/common/http';
import { Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';

import { Router } from '@angular/router';

@Injectable()
export class ErrorInterceptor implements HttpInterceptor {
   constructor(private router: Router) { }

   intercept(request: HttpRequest<any>, newRequest: HttpHandler): Observable<HttpEvent<any>> {

      return newRequest.handle(request).pipe(catchError(err => {

         if (err.status === 401) {
            //if 401 response returned from api, logout from application & redirect to login page.
            localStorage.clear();
            this.router.navigateByUrl('HOME');
         }
         const error = err.error.errorMessage || err.statusText;

         if (err.status === 404 || err.status === 400) {
            alert(error)
         }
         return Observable.throw(error);
      }));
   }
}