import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { User } from '../Models/user';
import { Tweet } from '../Models/tweet';
import { Token } from '../Models/token';
import { registerUser } from '../Models/registerUser';
const Requestheaders = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json',
    'Authorization': 'Bearer ' + localStorage.getItem('token')
  })
}

@Injectable({
  providedIn: 'root'
})
export class TweetappService {
  url: string = 'http://tweetapiachi.cxe5dnfhbxfjbndk.southindia.azurecontainer.io/api/v1.0/tweets/'
  constructor(private http: HttpClient) { }
  public Register(user: registerUser): Observable<String> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json; charset=utf-8');
    return this.http.post<String>(this.url + 'register', user, { headers, responseType: 'text' as 'json' })
  }
  public Login(username: string, password: string): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json; charset=utf-8');
    var body = {

      "emailId": username,
      "password": password
    };
    return this.http.post<any>(this.url + 'login/', body, { headers, responseType: 'json' })
  }
  public PostTweet(tweet: string, username: string): Observable<String> {
    var body = {
      "tweetText": tweet
    };
    const headers = new HttpHeaders().set('Content-Type', 'application/json; charset=utf-8',);
    return this.http.post<String>(this.url + username + '/add', body, Requestheaders)
  }
  public updateTweet(tweet: string, id: string, username: string): Observable<any> {
    var body = {
      "tweetText": tweet
    };
    const headers = new HttpHeaders().set('Content-Type', 'application/json; charset=utf-8');
    return this.http.put(this.url + username + '/update/' + id, body, Requestheaders)
  }
  public GetAllUsers(): Observable<any> {
    return this.http.get<any>(this.url + 'users/all', Requestheaders)
  }
  public GetTweetsByUser(username: string): Observable<any> {
    return this.http.get<any>(this.url + username, Requestheaders)
  }
  public GetAllTweets(): Observable<any> {
    return this.http.get<any>(this.url + 'all', Requestheaders)
  }
  public UpdatePassword(emailid: string, oldpassword: string, newpassword: string): Observable<String> {
    const headers = new HttpHeaders().set('Content-Type', 'text/html; charset=utf-8');
    return this.http.put<String>(this.url + 'update/' + escape(emailid) + ',' + escape(oldpassword) + ',' + escape(newpassword), { headers, responseType: 'text' })
  }
  public ForgotPassword(user: registerUser): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'text/html; charset=utf-8');
    var username = user.username;
    var body = {
      "emailId": user.emailId,
      "securityQuestion": user.securityQuestion,
      "securityAnswer": user.securityAnswer,
      "password": user.password,
      "confirmPassword": user.confirmPassword
    };
    return this.http.post(this.url + username + '/forgot', body, { headers, responseType: 'text' })
  }

  public PostComment(comment: string, username: string, id: string): Observable<any> {
    var body = {
      "tweetText": comment
    };
    const headers = new HttpHeaders().set('Content-Type', 'application/json; charset=utf-8');
    return this.http.put(this.url + username + '/reply/' + id, body, Requestheaders)
  }
  public GetLikes(username: string, id: string): Observable<any> {
    var body = null;
    return this.http.put(this.url + escape(username) + '/like/' + escape(id), body, Requestheaders)
  }
  public GetUserProfile(username: string): Observable<any> {
    return this.http.get<any>(this.url + 'user/search/' + escape(username), Requestheaders)
  }
  public DeleteTweet(username: string, tweetid: string): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'text/html; charset=utf-8');
    return this.http.delete(this.url + escape(username) + '/delete/' + escape(tweetid), Requestheaders)
  }
  public logout() {
    localStorage.clear();
  }
}
