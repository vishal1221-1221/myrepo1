import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from '../Models/user';
import { registerUser } from '../Models/registerUser';

import { TweetappService } from '../services/tweetapp.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  list: User[] = [];
  user: registerUser;
  submitted = false;
  userForm: FormGroup;
  img: string;
  selectedFile: File;
  message: string;
  emailValid: boolean = false;
  prePasswordCheck: boolean = false;
  passwordValidation: boolean = false;
  passwordLength: boolean = false;
  showElement: boolean = false;
  constructor(private frombuilder: FormBuilder, private service: TweetappService, private route: Router) { }

  ngOnInit() {
    this.userForm = this.frombuilder.group({
      firstname: ['', [Validators.required, Validators.pattern("^[A-Za-z]{0,}$")]],
      username: ['', Validators.required],
      emailId: ['', Validators.required],
      password: ['', [Validators.required]],
      confirmPassword: ['', Validators.required],
      dateOfBirth: ['', Validators.required],
      gender: ['', Validators.required],
      lastname: [''],
      securityQuestion: ['', Validators.required],
      securityAnswer: ['', Validators.required]
    });
  }
  emailValidation(emailId: HTMLInputElement) {
    if (/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/.test(emailId.value)) {
      this.emailValid = false;
      // console.log(this.emailValid)
    }
    else {

      this.emailValid = true;
      // console.log(this.emailValid)
    }
    if (emailId.value.length == 0) {
      this.emailValid = false
    }
  }

  //check if password and repassword are same

  checkPassword(password: HTMLInputElement, confirmPassword: HTMLInputElement) {

    // console.log(password.value,rePassword.value);
    if (password.value.length != 0) {
      this.prePasswordCheck = false;
      if (password.value == confirmPassword.value || confirmPassword.value.length == 0) {
        this.passwordValidation = false;
      } else {
        this.passwordValidation = true;
      }
    } else {
      this.prePasswordCheck = true;
    }
    if (confirmPassword.value.length == 0) {
      this.prePasswordCheck = false;
    }
    if (this.prePasswordCheck) {
      confirmPassword.value = "";
    }
  }

  // Check prePassword
  checkPrePassword(password: HTMLInputElement) {
    if (password.value.length >= 6 && password.value.length <= 12) {
      this.passwordLength = false;
    }
    else {
      this.passwordLength = true;
    }
    if (password.value.length != 0) {
      this.prePasswordCheck = false;
    } else {
      this.passwordLength = false;
    }
  }
  onSubmitUser() {
    this.submitted = true;
    if (this.userForm.invalid) {
      return;
    }
    else {
      if (this.emailValid == false && this.passwordValidation == false) {
        this.user = new registerUser();
        this.user.firstName = this.userForm.value["firstname"];
        this.user.lastName = this.userForm.value["lastname"];
        this.user.username = this.userForm.value["username"];
        this.user.emailId = this.userForm.value["emailId"];
        this.user.password = this.userForm.value["password"];
        this.user.confirmPassword = this.userForm.value["confirmPassword"];
        this.user.gender = this.userForm.value["gender"];
        this.user.securityQuestion = this.userForm.value["securityQuestion"];
        this.user.securityAnswer = this.userForm.value["securityAnswer"];
        this.user.dateOfBirth = this.userForm.value["dateOfBirth"];
        console.log(this.user)
        this.service.Register(this.user).subscribe(res => {
          alert("Successfully registered");
          console.log(res);
          this.route.navigateByUrl('HOME');
        },
          err => {
            alert("Failed to Register! Try again")
            console.log(err);
            this.onReset();
          }
        );
      }
    }
  }
  get f() { return this.userForm.controls; }
  onReset() {
    this.submitted = false;
    this.userForm.reset();
  }
  fileEvent(event: any) {
    this.img = event.target.files[0].name;
  }
}

