export class replies {
    public replyText:string;
    public userId:string;
    public dateAndTimeOfReply: Date;
    public lastName: string;
    public firstName: string;
    
}
