
import { replies } from 'src/app/Models/replies';

export class UserTweets {
    public id : string;
    public userId: string;
    public tweetText:string;
    public dateAndTimeOfTweet:Date;
    public firstName: string;
    public lastName:string;
    public datecalculated:string;
    public likes:number;
    public replies: replies[];
    public likedBy:string[];
}
 