export class registerUser {
    public firstName: string;
    public lastName:string;
    public username:string;
    public emailId:string;
    public password:string;
    public confirmPassword:string;
    public dateOfBirth :string;
    public gender:string;
    public securityQuestion:number;
    public securityAnswer:string;
}

