export class User {
    public userId:number;
    public firstName: string;
    public lastName:string;
    public username:string;
    public emailId:string;
    public password:string;
    public dateOfBirth :string;
    public gender:string;
    public contactNumber:string;
}
