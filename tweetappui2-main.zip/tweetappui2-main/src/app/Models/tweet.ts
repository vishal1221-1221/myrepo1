export class Tweet {
    public id:number;
    public userid: number;
    public tweetText:string;
    public userId:string;
    public username: string;
    public lastName: string;
    public firstName: string;
    public dateAndTimeOfTweet:Date;
    public likes:number;
}
