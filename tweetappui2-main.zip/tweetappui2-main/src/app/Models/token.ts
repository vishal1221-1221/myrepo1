export class Token {
    public userId:number;
    public username:string;
    public token:string;
    public message:string;
    public errorMessage:string;
}
